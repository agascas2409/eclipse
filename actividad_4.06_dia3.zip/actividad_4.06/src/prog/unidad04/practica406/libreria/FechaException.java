package prog.unidad04.practica406.libreria;

/**
 * Excepción particular de la clase Fecha
 */
public class FechaException extends Exception{ 

  //Constructor
  public FechaException() {}
  
}
