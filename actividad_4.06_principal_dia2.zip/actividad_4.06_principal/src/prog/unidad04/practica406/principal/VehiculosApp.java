package prog.unidad04.practica406.principal;

public class VehiculosApp {

  public static void main(String[] args) {

  }

}
